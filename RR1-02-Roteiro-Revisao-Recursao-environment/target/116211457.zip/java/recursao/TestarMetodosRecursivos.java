package recursao;

import java.util.Scanner;

public class TestarMetodosRecursivos {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int expoente = sc.nextInt(); // teste potencia de 2
		int n = sc.nextInt(); // teste fatorial
		int[] array = {1,2,3,4};
		MetodosRecursivos metodos = new MetodosRecursivos(); 
		
		System.out.println(metodos.potenciaDe2(expoente));
		System.out.println(metodos.calcularFatorial(n));
		System.out.println(metodos.calcularSomaArray(array, array.length));
		
		
	}
}
